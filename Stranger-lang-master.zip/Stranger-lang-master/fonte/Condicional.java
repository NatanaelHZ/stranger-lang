class Condicional{
    public int maior(Double a, Double b){
        if (a > b) {
            return 1;
        }else
            return 0;
    }
    public int maiorIgual(Double a, Double b){
        if (a > b) {
            return 1;
        }else
            return 0;
    }
    public int menor(Double a, Double b){
        if (a < b) {
            return 1;
        }else
            return 0;
    }
    public int menorIgual(Double a, Double b){
        if (a < b) {
            return 1;
        }else
            return 0;
    }

}