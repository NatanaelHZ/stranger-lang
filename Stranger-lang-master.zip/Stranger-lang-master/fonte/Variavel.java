/*
	Objetivo: Classe para criação das variáveis

	Autor: natanael_henrik28@outlook.com
*/

class Variavel {
	private String nome;
	private double valor;

	public void setNome(String n) {
		this.nome = n;
	}

	public String getNome() {
		return this.nome;
	}

	public void setValor(double v) {
		this.valor = v;
	}

	public double getValor() {
		return this.valor;
	}

}